package mbc.aiseat;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AiSeatApplicationTests {

    @Test
    void contextLoads() {
    }

}
