package mbc.aiseat;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AiSeatApplication {

    public static void main(String[] args) {
        SpringApplication.run(AiSeatApplication.class, args);
    }

}
